
package kanban;

/**
 *@author Thuso Diphoko
 * @version JDK 1.13
 * @since JDK 1.8
 */
public class User {
    
    
    public String userFirstName = null;
    public String userLastName = null;
    public String userUsername = null;
    public String userPassword = null;
    
    
    public String getUserFirstName() {
        return userFirstName;
    }
    
    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }
    
    public String getUserLastName() {
        return userLastName;
    } 
    
    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }
    
    public String getUserUsername() {
        return userUsername;
    }
    
    public void setUserUsername(String userUserName) {
        this.userUsername = userUserName;
    }
    
    public String getUserPassword() {
        return userPassword;
    }
    
    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
    
    
}
