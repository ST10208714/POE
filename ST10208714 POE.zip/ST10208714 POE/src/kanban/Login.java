/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanban;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Thuso Diphoko
 * @version JDK 1.13
 * @since JDK 1.8
 */
public class Login {

    
    User user = null;

    
    public Boolean checkUserName(String username) {

        
        final String USERNAME_PATTERN
                = "(?=.*[_]).{1,5}$";
        final Pattern pattern = Pattern.compile(USERNAME_PATTERN);
        Matcher matcher = pattern.matcher(username);
        return matcher.matches();

    }

    
    public Boolean checkPasswordComplexity(String password) {
        

        final String PASSWORD_PATTERN
                = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[r"
                + "!@#&()_-[{}]:;*,?/*~$^+=<>]).{8,}$";
        final Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    
    public String registerUser(String firstName, String lastName, String username, String password) {
       

        final String USERNAME_CAPTURED = "Username successfully captured";
        final String USERNAME_FORMAT_ERROR = "Username is not formatted corectly" + "formatted, please ensure" + "that your username contains" + "an underscore and is no more" + "than 5 characters in length";
        final String PASSWORD_CAPTURED = "Password succesfully captured";
        final String PASSWORD_FORMAT_ERROR = "Password is not correctly " + " formatted, please ensure that the password contains" + "at least 8 characters, a capital letter, a number and" + "a special character";

        
        String registrationMessage = "";

        
        if (!checkUserName(username)) {
            registrationMessage += USERNAME_FORMAT_ERROR + "\n";
        }
        
        if (!checkPasswordComplexity(password)) {
            registrationMessage += PASSWORD_FORMAT_ERROR + "\n";
        }
        
        if (registrationMessage.equals("")) {
            if (user == null) {
                user = new User();
            }

            user.setUserFirstName(firstName.trim());
            user.setUserLastName(lastName.trim());
            user.setUserUsername(username.trim());
            user.setUserPassword(password.trim());
            registrationMessage = USERNAME_CAPTURED + "\n"
                    + PASSWORD_CAPTURED + "\n";
        }

        return registrationMessage;

    }

    /**
     * Verifies the user's credentials before allowing the user to log in
     *
     * @param username:the username to be verified
     * @param password: the password to be verified
     * @return true is username is valid, false is otherwise
     */
    public Boolean loginUSer(String username, String password) {
        Boolean isValidCredentials = false;


        if (user != null) {
            if (username.trim().equals(user.getUserUsername())
                    && password.trim().equals(user.getUserPassword())) {
                isValidCredentials = true;
            }
        }
        return isValidCredentials;
    }

    /**
     * Returns an appropriate message to the user concerning the login status
     *
     * @param username:The username for getting the user's login status
     * @param isLoggedIn: login indicator to determine the correct message
     * @return a Message indicating the user's login
     */
    public String returnLoginStatus(String username, Boolean isLoggedIn) {
        String loginStatusMessage;

        
        if (isLoggedIn) {
            loginStatusMessage = "Welcome "
                    + user.getUserFirstName()
                    + " "
                    + user.getUserLastName()
                    + " , it is great to see you again";

        } else {
            loginStatusMessage = "Username or password incorrect," + "please try again";
        }
        return loginStatusMessage;
    }
    
    
    
}
